#import ollama

#url = "http://localhost:11434/api/chat"
#client = ollama.Client()

#model_name = "llama3.2"
#prompt = "write me a short poem about life"

#response = client.chat(model=model_name, messages=[{"role": "user", "content": prompt}])

#print("Response from ollama: ")
#print(response.choices[0].message)

#c:\Users\antonette\Downloads\import ollama.py


from __future__ import annotations

import argparse
import base64
import hashlib
import hmac
import json
import mimetypes
import os
import re
import secrets
import sys
import traceback
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from datetime import datetime, timedelta, timezone
from http.cookies import CookieError, SimpleCookie
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Iterator
from urllib.parse import urlsplit

import httpx   # installed automatically as a dependency of `ollama`
import ollama
import psycopg
from psycopg.errors import UniqueViolation


# ---------------------------------------------------------------------------
# 1. Configuration
# ---------------------------------------------------------------------------

SYSTEM_PROMPT = (
    "You are a helpful, friendly, general-purpose assistant. "
    "Answer the user's questions directly in clear, natural language. "
    "Do NOT write code, scripts, or code snippets unless the user explicitly "
    "asks for code. If the user asks for a poem, summary, explanation, "
    "recommendation or advice, respond in plain prose."
)


@dataclass
class AppConfig:
    backend: str = "ollama"
    model: str = "llama3.2"
    host: str = "http://localhost:11434"
    temperature: float = 0.7
    max_history_messages: int = 20  # user+assistant messages kept (system prompt is extra)
    serve_web: bool = False
    web_host: str = "127.0.0.1"
    web_port: int = 8000
    database_url: str = field(default_factory=lambda: os.environ.get("MEMOIR_DATABASE_URL", ""))
    secure_cookies: bool = False


PASSWORD_ITERATIONS = 310_000
SESSION_LIFETIME = timedelta(days=30)
MAX_REQUEST_BYTES = 1_000_000
MAX_MESSAGE_LENGTH = 20_000
EMAIL_PATTERN = re.compile(r"^[^@\s]+@[^@\s]+\.[^@\s]+$")


def hash_password(password: str) -> str:
    salt = secrets.token_bytes(16)
    digest = hashlib.pbkdf2_hmac(
        "sha256", password.encode("utf-8"), salt, PASSWORD_ITERATIONS
    )
    return "pbkdf2_sha256${}${}${}".format(
        PASSWORD_ITERATIONS,
        base64.urlsafe_b64encode(salt).decode("ascii"),
        base64.urlsafe_b64encode(digest).decode("ascii"),
    )


def verify_password(password: str, encoded: str) -> bool:
    try:
        algorithm, rounds, salt, expected = encoded.split("$")
        if algorithm != "pbkdf2_sha256":
            return False
        digest = hashlib.pbkdf2_hmac(
            "sha256",
            password.encode("utf-8"),
            base64.urlsafe_b64decode(salt.encode("ascii")),
            int(rounds),
        )
        return hmac.compare_digest(
            digest, base64.urlsafe_b64decode(expected.encode("ascii"))
        )
    except (ValueError, TypeError):
        return False


def initialize_database(database_url: str) -> None:
    if not database_url:
        raise SystemExit(
            "MEMOIR_DATABASE_URL is not set. Set it in the same shell before starting the web app."
        )

    schema = """
        CREATE TABLE IF NOT EXISTS users (
            id BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
            email TEXT NOT NULL UNIQUE,
            password_hash TEXT NOT NULL,
            created_at TIMESTAMPTZ NOT NULL DEFAULT now()
        );
        CREATE TABLE IF NOT EXISTS conversations (
            id BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
            user_id BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
            title TEXT NOT NULL,
            created_at TIMESTAMPTZ NOT NULL DEFAULT now()
        );
        CREATE TABLE IF NOT EXISTS messages (
            id BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
            conversation_id BIGINT NOT NULL REFERENCES conversations(id) ON DELETE CASCADE,
            role TEXT NOT NULL CHECK (role IN ('user', 'assistant')),
            content TEXT NOT NULL,
            created_at TIMESTAMPTZ NOT NULL DEFAULT now()
        );
        CREATE INDEX IF NOT EXISTS conversations_user_id_idx ON conversations(user_id);
        CREATE INDEX IF NOT EXISTS messages_conversation_id_idx ON messages(conversation_id);
        CREATE TABLE IF NOT EXISTS user_sessions (
            token_hash TEXT PRIMARY KEY,
            user_id BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
            expires_at TIMESTAMPTZ NOT NULL,
            created_at TIMESTAMPTZ NOT NULL DEFAULT now()
        );
        CREATE INDEX IF NOT EXISTS user_sessions_user_id_idx ON user_sessions(user_id);
    """
    try:
        with psycopg.connect(database_url) as connection:
            for statement in schema.split(";"):
                if statement.strip():
                    connection.execute(statement)
    except psycopg.Error as exc:
        raise SystemExit(
            "Could not initialize PostgreSQL. Check MEMOIR_DATABASE_URL, database access, and PostgreSQL status "
            f"({type(exc).__name__})."
        ) from exc


# ---------------------------------------------------------------------------
# 2. Application-level exceptions
#    The UI only knows about these, never about library-specific errors.
# ---------------------------------------------------------------------------

class BackendError(Exception):
    """Generic failure from a model backend."""


class BackendConnectionError(BackendError):
    """The model server could not be reached."""


class ModelNotAvailableError(BackendError):
    """The requested model does not exist on the server."""


# ---------------------------------------------------------------------------
# 3. Backend abstraction
#    To support a new provider, subclass ChatBackend and register it below.
# ---------------------------------------------------------------------------

Message = dict[str, str]  # {"role": "user" | "assistant" | "system", "content": "..."}


class ChatBackend(ABC):
    @abstractmethod
    def check_ready(self) -> None:
        """Raise BackendConnectionError / ModelNotAvailableError if unusable."""

    @abstractmethod
    def stream_chat(self, messages: list[Message]) -> Iterator[str]:
        """Yield the reply as a stream of text chunks."""


class OllamaBackend(ChatBackend):
    def __init__(self, config: AppConfig) -> None:
        self.model = config.model
        self.temperature = config.temperature
        self.host = config.host
        self.client = ollama.Client(host=config.host)

    def _translate(self, exc: Exception) -> BackendError:
        """Convert library-specific exceptions into our own."""
        if isinstance(exc, (ConnectionError, httpx.ConnectError, httpx.TimeoutException)):
            return BackendConnectionError(
                f"Cannot reach Ollama at {self.host}. "
                "Make sure Ollama is installed and running (try `ollama serve`)."
            )
        if isinstance(exc, ollama.ResponseError):
            if exc.status_code == 404:
                return ModelNotAvailableError(
                    f"Model '{self.model}' is not installed. "
                    f"Download it with: ollama pull {self.model}"
                )
            return BackendError(f"Ollama returned an error ({exc.status_code}): {exc.error}")
        return BackendError(f"Unexpected error: {exc}")

    def check_ready(self) -> None:
        try:
            self.client.show(self.model)  # 404 if the model isn't installed
        except Exception as exc:
            raise self._translate(exc) from exc

    def stream_chat(self, messages: list[Message]) -> Iterator[str]:
        try:
            stream = self.client.chat(
                model=self.model,
                messages=messages,
                stream=True,
                options={"temperature": self.temperature},
            )
            for chunk in stream:
                text = chunk["message"]["content"]
                if text:
                    yield text
        except Exception as exc:
            raise self._translate(exc) from exc


# Registry: add new backends here, e.g. BACKENDS["openai"] = OpenAIBackend
BACKENDS: dict[str, type[ChatBackend]] = {
    "ollama": OllamaBackend,
}


def create_backend(config: AppConfig) -> ChatBackend:
    try:
        return BACKENDS[config.backend](config)
    except KeyError:
        raise SystemExit(
            f"Unknown backend '{config.backend}'. Available: {', '.join(BACKENDS)}"
        )


# ---------------------------------------------------------------------------
# 4. Conversation memory
# ---------------------------------------------------------------------------

@dataclass
class Conversation:
    system_prompt: str
    max_messages: int
    history: list[Message] = field(default_factory=list)

    def add_user(self, text: str) -> None:
        self.history.append({"role": "user", "content": text})

    def add_assistant(self, text: str) -> None:
        self.history.append({"role": "assistant", "content": text})

    def discard_last(self) -> None:
        """Remove the last message (used when a request fails)."""
        if self.history:
            self.history.pop()

    def reset(self) -> None:
        self.history.clear()

    def build_messages(self) -> list[Message]:
        """System prompt + the most recent N messages (keeps context bounded)."""
        recent = self.history[-self.max_messages:]
        return [{"role": "system", "content": self.system_prompt}, *recent]


# ---------------------------------------------------------------------------
# 5. Terminal UI
# ---------------------------------------------------------------------------

HELP_TEXT = """Commands:
  /reset   clear the conversation history
  /help    show this message
  /quit    exit (Ctrl+C also works)"""


def run_chat(backend: ChatBackend, config: AppConfig) -> None:
    conversation = Conversation(SYSTEM_PROMPT, config.max_history_messages)

    print(f"Chatting with '{config.model}' via {config.backend}. Type /help for commands.\n")

    while True:
        try:
            user_input = input("You: ").strip()
        except (EOFError, KeyboardInterrupt):
            print("\nGoodbye!")
            return

        if not user_input:
            continue

        command = user_input.lower()
        if command in {"/quit", "/exit"}:
            print("Goodbye!")
            return
        if command == "/help":
            print(HELP_TEXT + "\n")
            continue
        if command == "/reset":
            conversation.reset()
            print("Conversation cleared.\n")
            continue

        conversation.add_user(user_input)
        print("AI: ", end="", flush=True)

        reply_parts: list[str] = []
        try:
            for piece in backend.stream_chat(conversation.build_messages()):
                print(piece, end="", flush=True)  # live output in the terminal
                reply_parts.append(piece)
            print("\n")
        except KeyboardInterrupt:
            print("\n[Response interrupted]\n")
        except BackendError as err:
            print(f"\n[Error] {err}\n")
            conversation.discard_last()  # don't keep a user turn that got no answer
            continue

        reply = "".join(reply_parts).strip()
        if reply:
            conversation.add_assistant(reply)
        else:
            conversation.discard_last()


# ---------------------------------------------------------------------------
# 6. Web app API and static file server
# ---------------------------------------------------------------------------

def create_web_handler(backend: ChatBackend, config: AppConfig) -> type[SimpleHTTPRequestHandler]:
    directory = Path(__file__).resolve().parent
    app_files = {
        "/": "memoir.html",
        "/memoir.html": "memoir.html",
        "/memoir.css": "memoir.css",
        "/memoir.js": "memoir.js",
        "/memoirapi.js": "memoirapi.js",
        "/memoirstore.js": "memoirstore.js",
        "/memoirapp.js": "memoirapp.js",
    }
    dummy_password_hash = hash_password("not-a-real-user-password")

    class WebHandler(SimpleHTTPRequestHandler):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, directory=str(directory), **kwargs)

        def do_GET(self) -> None:
            if self.path.startswith("/api/"):
                try:
                    self._handle_api_get()
                except psycopg.Error as exc:
                    self.log_error("PostgreSQL request failed: %s", type(exc).__name__)
                    self._send_json(503, {"detail": "PostgreSQL request failed. Check the backend configuration."})
                return

            filename = app_files.get(self.path)
            if filename is None:
                self._send_json(404, {"detail": "Not found."})
                return

            try:
                content = (directory / filename).read_bytes()
            except OSError:
                self._send_json(404, {"detail": f"App file '{filename}' is missing."})
                return

            self.send_response(200)
            content_type = mimetypes.guess_type(filename)[0] or "application/octet-stream"
            self.send_header("Content-Type", content_type)
            self.send_header("Content-Length", str(len(content)))
            self.send_header("Cache-Control", "no-store")
            self.send_header("X-Content-Type-Options", "nosniff")
            self.send_header("Content-Security-Policy", "default-src 'self'; style-src 'self' 'unsafe-inline'; object-src 'none'; base-uri 'self'; frame-ancestors 'none'")
            self.end_headers()
            self.wfile.write(content)

        def do_POST(self) -> None:
            if not self._check_same_origin():
                self._send_json(403, {"detail": "Request origin was rejected."})
                return
            try:
                self._handle_api_post()
            except psycopg.Error as exc:
                self.log_error("PostgreSQL request failed: %s", type(exc).__name__)
                self._send_json(503, {"detail": "PostgreSQL request failed. Check the backend configuration."})

        def do_DELETE(self) -> None:
            if not self._check_same_origin():
                self._send_json(403, {"detail": "Request origin was rejected."})
                return
            try:
                self._handle_api_delete()
            except psycopg.Error as exc:
                self.log_error("PostgreSQL request failed: %s", type(exc).__name__)
                self._send_json(503, {"detail": "PostgreSQL request failed. Check the backend configuration."})

        def _handle_api_get(self) -> None:
            if self.path == "/api/me":
                user = self._authenticated_user()
                if user is None:
                    self._send_json(401, {"detail": "Please sign in."})
                else:
                    self._send_json(200, {"user": user})
                return

            if self.path == "/api/chats":
                user = self._authenticated_user()
                if user is None:
                    self._send_json(401, {"detail": "Please sign in."})
                    return
                self._send_json(200, {"chats": self._list_chats(int(user["id"]))})
                return

            self._send_json(404, {"detail": "Not found."})

        def _handle_api_post(self) -> None:
            if self.path not in {"/api/register", "/api/login", "/api/logout", "/api/chat"}:
                self._send_json(404, {"detail": "Not found."})
                return
            try:
                payload = self._read_json()
            except ValueError as exc:
                self._send_json(400, {"detail": str(exc)})
                return

            if self.path == "/api/register":
                self._register(payload)
                return
            if self.path == "/api/login":
                self._login(payload)
                return
            if self.path == "/api/logout":
                token = self._session_token()
                if token:
                    with psycopg.connect(config.database_url) as connection:
                        connection.execute(
                            "DELETE FROM user_sessions WHERE token_hash = %s",
                            (self._token_hash(token),),
                        )
                self._send_json(200, {"ok": True}, self._session_cookie(clear=True))
                return

            user = self._authenticated_user()
            if user is None:
                self._send_json(401, {"detail": "Please sign in."})
                return
            try:
                self._send_chat_message(payload, user)
            except psycopg.Error:
                raise
            except Exception:
                traceback.print_exc()
                self._send_json(
                    500,
                    {"detail": "Unexpected chat error. Check the Python server console."},
                )

        def _handle_api_delete(self) -> None:
            prefix = "/api/chats/"
            if not self.path.startswith(prefix):
                self._send_json(404, {"detail": "Not found."})
                return
            user = self._authenticated_user()
            if user is None:
                self._send_json(401, {"detail": "Please sign in."})
                return
            conversation_id = self._parse_id(self.path[len(prefix):])
            if conversation_id is None:
                self._send_json(404, {"detail": "Chat not found."})
                return
            with psycopg.connect(config.database_url) as connection:
                result = connection.execute(
                    "DELETE FROM conversations WHERE id = %s AND user_id = %s",
                    (conversation_id, int(user["id"])),
                )
            if result.rowcount == 0:
                self._send_json(404, {"detail": "Chat not found."})
            else:
                self._send_json(200, {"ok": True})

        def _register(self, payload: dict[str, object]) -> None:
            email = payload.get("email")
            password = payload.get("password")
            if not isinstance(email, str) or not isinstance(password, str):
                self._send_json(400, {"detail": "Email and password are required."})
                return
            email = email.strip().lower()
            if len(email) > 254 or not EMAIL_PATTERN.fullmatch(email):
                self._send_json(400, {"detail": "Enter a valid email address."})
                return
            if not 12 <= len(password) <= 128:
                self._send_json(400, {"detail": "Password must be between 12 and 128 characters."})
                return

            try:
                with psycopg.connect(config.database_url) as connection:
                    row = connection.execute(
                        "INSERT INTO users (email, password_hash) VALUES (%s, %s) RETURNING id, email",
                        (email, hash_password(password)),
                    ).fetchone()
            except UniqueViolation:
                self._send_json(409, {"detail": "An account with that email already exists."})
                return
            if row is None:
                self._send_json(500, {"detail": "Could not create the account."})
                return
            user = {"id": str(row[0]), "email": row[1]}
            token = self._create_session(int(row[0]))
            self._send_json(201, {"user": user}, self._session_cookie(token))

        def _login(self, payload: dict[str, object]) -> None:
            email = payload.get("email")
            password = payload.get("password")
            if not isinstance(email, str) or not isinstance(password, str):
                self._send_json(400, {"detail": "Email and password are required."})
                return
            email = email.strip().lower()
            if len(email) > 254 or len(password) > 128:
                self._send_json(401, {"detail": "Email or password is incorrect."})
                return
            with psycopg.connect(config.database_url) as connection:
                row = connection.execute(
                    "SELECT id, email, password_hash FROM users WHERE email = %s",
                    (email,),
                ).fetchone()
            stored_hash = row[2] if row else dummy_password_hash
            if not verify_password(password, stored_hash) or row is None:
                self._send_json(401, {"detail": "Email or password is incorrect."})
                return
            user = {"id": str(row[0]), "email": row[1]}
            token = self._create_session(int(row[0]))
            self._send_json(200, {"user": user}, self._session_cookie(token))

        def _send_chat_message(self, payload: dict[str, object], user: dict[str, str]) -> None:
            content = payload.get("content")
            raw_id = payload.get("conversation_id")
            if not isinstance(content, str) or not content.strip():
                self._send_json(400, {"detail": "Message content is required."})
                return
            content = content.strip()
            if len(content) > MAX_MESSAGE_LENGTH:
                self._send_json(413, {"detail": f"Messages must be at most {MAX_MESSAGE_LENGTH} characters."})
                return

            conversation_id = None if raw_id is None else self._parse_id(raw_id)
            if raw_id is not None and conversation_id is None:
                self._send_json(404, {"detail": "Chat not found."})
                return

            history: list[Message] = []
            title = content[:40]
            if conversation_id is not None:
                with psycopg.connect(config.database_url) as connection:
                    conversation = connection.execute(
                        "SELECT title FROM conversations WHERE id = %s AND user_id = %s",
                        (conversation_id, int(user["id"])),
                    ).fetchone()
                    if conversation is None:
                        self._send_json(404, {"detail": "Chat not found."})
                        return
                    title = conversation[0]
                    rows = connection.execute(
                        "SELECT role, content FROM messages WHERE conversation_id = %s ORDER BY id",
                        (conversation_id,),
                    ).fetchall()
                history = [{"role": row[0], "content": row[1]} for row in rows]

            messages = history[-config.max_history_messages:]
            messages.append({"role": "user", "content": content})
            try:
                reply = "".join(
                    backend.stream_chat(
                        [{"role": "system", "content": SYSTEM_PROMPT}, *messages]
                    )
                ).strip()
            except BackendError as exc:
                self._send_json(502, {"detail": str(exc)})
                return
            if not reply:
                self._send_json(502, {"detail": "The model returned an empty response."})
                return

            with psycopg.connect(config.database_url) as connection:
                if conversation_id is None:
                    row = connection.execute(
                        "INSERT INTO conversations (user_id, title) VALUES (%s, %s) RETURNING id",
                        (int(user["id"]), title),
                    ).fetchone()
                    if row is None:
                        self._send_json(500, {"detail": "Could not save the chat."})
                        return
                    conversation_id = int(row[0])
                else:
                    exists = connection.execute(
                        "SELECT id FROM conversations WHERE id = %s AND user_id = %s FOR UPDATE",
                        (conversation_id, int(user["id"])),
                    ).fetchone()
                    if exists is None:
                        self._send_json(404, {"detail": "Chat not found."})
                        return
                connection.execute(
                    "INSERT INTO messages (conversation_id, role, content) VALUES (%s, %s, %s)",
                    (conversation_id, "user", content),
                )
                connection.execute(
                    "INSERT INTO messages (conversation_id, role, content) VALUES (%s, %s, %s)",
                    (conversation_id, "assistant", reply),
                )

            chat = {
                "id": str(conversation_id),
                "title": title,
                "messages": [
                    *history,
                    {"role": "user", "content": content},
                    {"role": "assistant", "content": reply},
                ],
            }
            self._send_json(200, {"reply": reply, "chat": chat})

        def _read_json(self) -> dict[str, object]:
            try:
                length = int(self.headers.get("Content-Length", ""))
            except ValueError as exc:
                raise ValueError("A valid Content-Length is required.") from exc
            if length <= 0 or length > MAX_REQUEST_BYTES:
                raise ValueError(
                    f"Request body must be between 1 byte and {MAX_REQUEST_BYTES // 1_000_000} MB."
                )
            try:
                payload = json.loads(self.rfile.read(length))
            except (json.JSONDecodeError, UnicodeDecodeError) as exc:
                raise ValueError("Request body must be valid JSON.") from exc
            if not isinstance(payload, dict):
                raise ValueError("Request body must be a JSON object.")
            return payload

        def _authenticated_user(self) -> dict[str, str] | None:
            token = self._session_token()
            if token is None:
                return None
            with psycopg.connect(config.database_url) as connection:
                row = connection.execute(
                    """
                    SELECT users.id, users.email
                    FROM user_sessions
                    JOIN users ON users.id = user_sessions.user_id
                    WHERE user_sessions.token_hash = %s
                      AND user_sessions.expires_at > now()
                    """,
                    (self._token_hash(token),),
                ).fetchone()
            if row is None:
                return None
            return {"id": str(row[0]), "email": row[1]}

        def _create_session(self, user_id: int) -> str:
            token = secrets.token_urlsafe(32)
            expires_at = datetime.now(timezone.utc) + SESSION_LIFETIME
            with psycopg.connect(config.database_url) as connection:
                connection.execute("DELETE FROM user_sessions WHERE expires_at <= now()")
                connection.execute(
                    "INSERT INTO user_sessions (token_hash, user_id, expires_at) VALUES (%s, %s, %s)",
                    (self._token_hash(token), user_id, expires_at),
                )
            return token

        def _session_token(self) -> str | None:
            cookie = SimpleCookie()
            try:
                cookie.load(self.headers.get("Cookie", ""))
            except CookieError:
                return None
            morsel = cookie.get("memoir_session")
            return morsel.value if morsel else None

        @staticmethod
        def _token_hash(token: str) -> str:
            return hashlib.sha256(token.encode("ascii")).hexdigest()

        def _session_cookie(self, token: str | None = None, clear: bool = False) -> str:
            if clear:
                value = "memoir_session=; Path=/; HttpOnly; SameSite=Strict; Max-Age=0"
            else:
                value = (
                    f"memoir_session={token}; Path=/; HttpOnly; SameSite=Strict; "
                    f"Max-Age={int(SESSION_LIFETIME.total_seconds())}"
                )
            if config.secure_cookies:
                value += "; Secure"
            return value

        def _check_same_origin(self) -> bool:
            origin = self.headers.get("Origin")
            host = self.headers.get("Host", "")
            if not origin or not host:
                return False
            parsed = urlsplit(origin)
            expected_scheme = "https" if config.secure_cookies else "http"
            return (
                parsed.scheme == expected_scheme
                and parsed.netloc.casefold() == host.casefold()
                and not parsed.path
                and not parsed.query
                and not parsed.fragment
            )

        def _list_chats(self, user_id: int) -> list[dict[str, object]]:
            with psycopg.connect(config.database_url) as connection:
                rows = connection.execute(
                    """
                    SELECT c.id, c.title, m.role, m.content
                    FROM conversations AS c
                    LEFT JOIN messages AS m ON m.conversation_id = c.id
                    WHERE c.user_id = %s
                    ORDER BY c.created_at DESC, c.id DESC, m.id
                    """,
                    (user_id,),
                ).fetchall()
            chats: list[dict[str, object]] = []
            for row in rows:
                if not chats or chats[-1]["id"] != str(row[0]):
                    chats.append({"id": str(row[0]), "title": row[1], "messages": []})
                if row[2] is not None:
                    chats[-1]["messages"].append({"role": row[2], "content": row[3]})
            return chats

        @staticmethod
        def _parse_id(value: object) -> int | None:
            text = str(value)
            if len(text) > 19 or not text.isascii() or not text.isdecimal():
                return None
            try:
                parsed = int(text)
            except ValueError:
                return None
            return parsed if 0 < parsed <= 9_223_372_036_854_775_807 else None

        def _send_json(
            self, status: int, payload: dict[str, object], cookie: str | None = None
        ) -> None:
            encoded = json.dumps(payload, ensure_ascii=False).encode("utf-8")
            self.send_response(status)
            self.send_header("Content-Type", "application/json; charset=utf-8")
            self.send_header("Content-Length", str(len(encoded)))
            self.send_header("Cache-Control", "no-store")
            self.send_header("X-Content-Type-Options", "nosniff")
            if cookie:
                self.send_header("Set-Cookie", cookie)
            self.end_headers()
            self.wfile.write(encoded)

    return WebHandler


def serve_web(backend: ChatBackend, config: AppConfig) -> None:
    handler = create_web_handler(backend, config)
    server = ThreadingHTTPServer((config.web_host, config.web_port), handler)
    print(f"Memoir chat is available at http://{config.web_host}:{config.web_port}/")
    print("Press Ctrl+C to stop.")
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\nWeb server stopped.")
    finally:
        server.server_close()


# ---------------------------------------------------------------------------
# 7. Entry point
# ---------------------------------------------------------------------------

def parse_args() -> AppConfig:
    defaults = AppConfig()
    parser = argparse.ArgumentParser(description="Terminal chat with a local LLM")
    parser.add_argument("--backend", default=defaults.backend, choices=list(BACKENDS))
    parser.add_argument("--model", default=defaults.model)
    parser.add_argument("--host", default=defaults.host)
    parser.add_argument("--temperature", type=float, default=defaults.temperature)
    parser.add_argument("--web", action="store_true", help="serve the memoir web app and chat API")
    parser.add_argument("--web-host", default=defaults.web_host)
    parser.add_argument("--web-port", type=int, default=defaults.web_port)
    parser.add_argument(
        "--secure-cookies",
        action="store_true",
        help="mark login cookies Secure when served behind an HTTPS reverse proxy",
    )
    args = parser.parse_args()
    return AppConfig(
        backend=args.backend,
        model=args.model,
        host=args.host,
        temperature=args.temperature,
        serve_web=args.web,
        web_host=args.web_host,
        web_port=args.web_port,
        database_url=defaults.database_url,
        secure_cookies=args.secure_cookies,
    )


def main() -> None:
    config = parse_args()
    backend = create_backend(config)

    try:
        backend.check_ready()
    except BackendError as err:
        print(f"[Startup error] {err}", file=sys.stderr)
        sys.exit(1)

    if config.serve_web:
        initialize_database(config.database_url)
        serve_web(backend, config)
        return

    run_chat(backend, config)


if __name__ == "__main__":
    main()
