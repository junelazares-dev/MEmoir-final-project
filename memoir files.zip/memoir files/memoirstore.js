// Conversation history, kept in the browser (localStorage) so chats survive a refresh.
window.Store = (() => {
  const KEY = "ai_chats_v1";
  let s = { chats: [], activeId: null };
  try { s = JSON.parse(localStorage.getItem(KEY)) || s; } catch {}
  const save = () => { try { localStorage.setItem(KEY, JSON.stringify(s)); } catch {} };

  return {
    get chats() { return s.chats; },
    get active() { return s.chats.find((c) => c.id === s.activeId) || null; },
    startNew() { s.activeId = null; save(); },
    select(id) { s.activeId = id; save(); },
    create(title) {
      const chat = { id: Date.now().toString(36), title: title.slice(0, 40), messages: [] };
      s.chats.unshift(chat);
      s.activeId = chat.id;
      save();
      return chat;
    },
    push(chat, message) { chat.messages.push(message); save(); },
    pop(chat) { chat.messages.pop(); save(); },
    remove(id) {
      s.chats = s.chats.filter((c) => c.id !== id);
      if (s.activeId === id) s.activeId = null;
      save();
    },
  };
})();
