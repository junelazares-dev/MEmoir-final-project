// Branding + backend connection settings.
window.APP_CONFIG = {
  appName: "Memoir",                       // <- your assistant's name
  tagline: "How can I help you today?",

  // The Python server serves this page and handles chat on the same origin.
  apiBase: "",
  chatEndpoint: "/api/chat",

  suggestions: [
    "Explain how photosynthesis works",
    "Write a short poem about life",
    "Summarize the benefits of sleep",
    "Recommend a few books on productivity",
  ],

  // Shape of the request sent to your backend.
  // Default: the full conversation as [{role, content}, ...].
  buildBody: (messages) => ({ messages }),

  // Pull the reply text out of a JSON response (used when the backend returns JSON).
  // If your backend streams plain text instead, this is not needed.
  extractReply: (data) =>
    data.reply ?? data.response ?? data.message?.content ?? data.content,
};
