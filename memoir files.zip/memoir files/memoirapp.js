(() => {
  const C = APP_CONFIG;
  const $ = (id) => document.getElementById(id);
  const el = (tag, cls, text) => {
    const e = document.createElement(tag);
    if (cls) e.className = cls;
    if (text != null) e.textContent = text;
    return e;
  };
  const LOGO = '<svg viewBox="0 0 24 24"><path d="M12 2l2.4 6.6L21 11l-6.6 2.4L12 20l-2.4-6.6L3 11l6.6-2.4z"/></svg>';

  // ---------- Reusable components ----------
  const Logo = (size = "") => {
    const s = el("span", "logo " + size);
    s.innerHTML = LOGO;
    return s;
  };

  function Message(role, text = "") {
    const row = el("div", "msg " + role);
    const bubble = el("div", "bubble", text); // textContent => safe from HTML injection
    if (role === "assistant") row.append(Logo("sm"));
    row.append(bubble);
    return {
      row,
      setTyping() { bubble.className = "bubble typing"; bubble.innerHTML = "<i></i><i></i><i></i>"; },
      setText(t) { bubble.className = "bubble"; bubble.textContent = t; },
    };
  }

  function ChatItem(chat, active) {
    const row = el("div", "chat-item" + (active ? " active" : ""));
    const title = el("span", "", chat.title);
    title.onclick = () => selectChat(chat.id);
    const del = el("button", "del", "×");
    del.setAttribute("aria-label", "Delete chat");
    del.onclick = () => deleteChat(chat.id);
    row.append(title, del);
    return row;
  }

  // ---------- Elements & state ----------
  const main = $("main"), messages = $("messages"), input = $("input");
  const sendBtn = $("send"), banner = $("banner"), sidebar = $("sidebar"), scrim = $("scrim");
  let busy = false;

  const scrollDown = () => { messages.scrollTop = messages.scrollHeight; };
  const showError = (msg) => { banner.textContent = msg; banner.hidden = false; };
  const hideError = () => { banner.hidden = true; };
  const closeMenu = () => { sidebar.classList.remove("open"); scrim.classList.remove("show"); };

  function autosize() {
    input.style.height = "auto";
    input.style.height = Math.min(input.scrollHeight, 200) + "px";
    sendBtn.disabled = busy || !input.value.trim();
  }

  function render() {
    const chat = Store.active;
    main.classList.toggle("empty", !chat || !chat.messages.length);
    messages.replaceChildren(...(chat ? chat.messages.map((m) => Message(m.role, m.content).row) : []));
    $("history").replaceChildren(...Store.chats.map((c) => ChatItem(c, chat && c.id === chat.id)));
    scrollDown();
  }

  // ---------- Actions ----------
  function newChat() { if (busy) return; Store.startNew(); hideError(); render(); closeMenu(); input.focus(); }
  function selectChat(id) { if (busy) return; Store.select(id); hideError(); render(); closeMenu(); }
  function deleteChat(id) { if (busy) return; Store.remove(id); render(); }

  async function submit(raw) {
    const text = raw.trim();
    if (!text || busy) return;
    hideError();

    const chat = Store.active || Store.create(text);
    Store.push(chat, { role: "user", content: text });
    input.value = "";
    busy = true;
    render();
    autosize();

    const reply = Message("assistant");
    reply.setTyping();
    messages.append(reply.row);
    main.classList.remove("empty");
    scrollDown();

    let full = "";
    try {
      full = await Api.send(chat.messages, (piece) => {
        reply.setText((reply.text = (reply.text || "") + piece));
        scrollDown();
      });
      Store.push(chat, { role: "assistant", content: full });
    } catch (err) {
      reply.row.remove();
      Store.pop(chat);                 // drop the unanswered question
      if (!chat.messages.length) Store.remove(chat.id);
      input.value = text;              // give the text back so nothing is lost
      showError(err.message);
    } finally {
      busy = false;
      render();
      autosize();
      input.focus();
    }
  }

  // ---------- Setup ----------
  document.title = C.appName;
  document.querySelectorAll("[data-name]").forEach((n) => (n.textContent = C.appName));
  document.querySelectorAll("[data-tagline]").forEach((n) => (n.textContent = C.tagline));
  document.querySelectorAll("[data-logo]").forEach((n) => n.replaceWith(Logo(n.dataset.logo)));

  $("suggestions").append(...C.suggestions.map((s) => {
    const b = el("button", "", s);
    b.type = "button";
    b.onclick = () => submit(s);
    return b;
  }));

  const root = document.documentElement;
  const setTheme = (t) => { root.dataset.theme = t; try { localStorage.setItem("theme", t); } catch {} };
  let saved = null;
  try { saved = localStorage.getItem("theme"); } catch {}
  setTheme(saved || (matchMedia("(prefers-color-scheme: dark)").matches ? "dark" : "light"));

  $("themeBtn").onclick = () => setTheme(root.dataset.theme === "dark" ? "light" : "dark");
  $("newChat").onclick = newChat;
  $("menuBtn").onclick = () => { sidebar.classList.add("open"); scrim.classList.add("show"); };
  scrim.onclick = closeMenu;
  $("composer").onsubmit = (e) => { e.preventDefault(); submit(input.value); };
  input.oninput = autosize;
  input.onkeydown = (e) => {
    if (e.key === "Enter" && !e.shiftKey && !e.isComposing) {
      e.preventDefault();
      submit(input.value);
    }
  };

  render();
  autosize();
})();
