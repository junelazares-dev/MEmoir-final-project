// API client. Sends the conversation to the backend and reports the reply
// through onChunk(textPiece). Supports a JSON reply or a streamed text reply.
window.Api = {
  async send(messages, onChunk) {
    const c = APP_CONFIG;
    let res;
    try {
      res = await fetch(c.apiBase + c.chatEndpoint, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(c.buildBody(messages)),
      });
    } catch {
      throw new Error(`Can't reach the assistant backend at ${c.apiBase}. Make sure it is running and allows requests from this page (CORS).`);
    }

    if (!res.ok) {
      let detail = "";
      try { const j = await res.json(); detail = j.detail || j.error || ""; } catch {}
      throw new Error(`The backend returned an error (${res.status})${detail ? ": " + detail : "."}`);
    }

    if ((res.headers.get("content-type") || "").includes("json")) {
      const text = c.extractReply(await res.json());
      if (!text) throw new Error("The backend replied in an unexpected format. Check extractReply in config.js.");
      onChunk(text);
      return text;
    }

    const reader = res.body.getReader();
    const decoder = new TextDecoder();
    let full = "";
    for (;;) {
      const { done, value } = await reader.read();
      if (done) break;
      const piece = decoder.decode(value, { stream: true });
      full += piece;
      onChunk(piece);
    }
    if (!full.trim()) throw new Error("The backend returned an empty response.");
    return full;
  },
};
